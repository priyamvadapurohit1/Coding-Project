
#ifndef LARGE_SUM_H
#define LARGE_SUM_H
#include <string>
using namespace std;

void  enter_nums(string &num1, string &num2, int digit1[], int digit2[]) ;


void add_large_numbers(int num1[], int  num2[], int sum[]);


void display_num(int sum[]);

#endif LARGE_SUM_H