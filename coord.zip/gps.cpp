#include <iostream>
#include <iomanip>
#include "coord.h" // no quotation marks

using namespace std;

int main() {
    Point3D point1;  // we need to declare these using point 3D
    Point3D point2;

    Point3D p1;
    get_point(p1);
    Point3D p2;
    get_point(p2);

    print_point(p1);
    print_point(p2);

    cout<<"Spatial Distance: "<< setw(10) <<spatial_dist(p1,p2)<<endl;
    cout<<"plani_dist: "<<setw(10)<<plani_dist(p1,p2)<<endl;
    cout<<"height dist: "<<setw(10)<<height_diff(p1,p2)<<endl;
    cout<<"azimuth: "<<setw(10)<<azimuth(p1,p2)<<"degrees"<<endl;






    return 0;


}