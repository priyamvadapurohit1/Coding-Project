#include "coord.h"
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;


void get_point(Point3D &pt) {
    cout<<"Enter point ID:"<<endl;
    cin>>pt.id;
    cout<<"You entered point ID: "<<pt.id<<endl;
    cout<<"Enter the coordinate for X:";
    cin>>pt.x;
    cout<<"You entered this value:"<<pt.x<<endl;
    cout<<"Enter coordinates for Y";
    cin>>pt.y;
    cout<<"You entered this value:"<<pt.y<<endl;
    cout<<"Enter coordinates for Z";
    cin>>pt.z;
    cout<<"You entered this value:"<<pt.z<<endl;
    cout<<"Enter the order x,y,z";
    cin>>pt.order;  // we need to get the order
    cout<<"You entered this value"<<pt.order<<endl;
}

void print_point(const Point3D &pt) { //we call the function a void and we add a const Point3D and pt
    cout<<"Point ID: "<<setw(10)<<pt.id<<endl;
    cout<<"X Coordinate: "<<setw(10)<<pt.x<<endl;
    cout<<"Y Coordinate: "<<setw(10)<<pt.y<<endl;
    cout<<"Z Coordinate: "<<setw(10)<<pt.z<<endl;
    cout<<"Classification: "<<setw(10)<<pt.order<<endl;
}

double spatial_dist(const Point3D &pt1, const Point3D &pt2) {
    double dx=pt2.x-pt1.x;
    double dy=pt1.y-pt2.y;
    double dz=pt1.z-pt2.z;
    return sqrt((dx*dx)+(dy*dy)+(dz*dz));
}
double plani_dist(const Point3D &pt1, const Point3D &pt2) {
    double dx=pt1.x-pt2.x;
    double dy=pt1.y-pt2.y;
    return sqrt((dx*dx)+(dy*dy));

}
double height_diff(const Point3D &pt1, const Point3D &pt2) {
    return (pt2.z-pt1.z);

}
double azimuth(const Point3D &pt1, const Point3D &pt2) {
    double dx=pt2.x-pt1.x;
    double dy=pt1.y-pt2.y;
    double angle=atan2(dy, dx);
    double degrees=(angle*(180/M_PI));
    
    return degrees;

}