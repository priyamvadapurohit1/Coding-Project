#ifndef COORD_H // we need to include this in coord h
#define COORD_H  // this is what the header file is


// to declare a structure
struct Point3D {
    int id;
    double x,y,z;
    char order; // this is what gives the order of ( A=high accurate, B=medium, C=low)
};
void get_point(Point3D &pt);
void print_point(const Point3D &pt);
double spatial_dist(const Point3D &pt1, const Point3D &pt2);
double plani_dist(const Point3D &pt1, const Point3D &pt2);
double height_diff(const Point3D &pt1, const Point3D &pt2);
double azimuth(const Point3D &pt1, const Point3D &pt2);


#endif